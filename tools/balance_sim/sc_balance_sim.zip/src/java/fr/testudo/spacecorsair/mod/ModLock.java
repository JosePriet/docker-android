package fr.testudo.spacecorsair.mod;

import android.widget.Toast;
import fr.testudo.spacecorsair.business.loot.SpaceObject;
import fr.testudo.spacecorsair.business.loot.SpaceObjectType;
import fr.testudo.spacecorsair.business.loot.stuff.GearSpec;
import fr.testudo.spacecorsair.business.loot.stuff.playerShip.PlayerShipSpec;
import fr.testudo.spacecorsair.business.player.Inventory;
import fr.testudo.spacecorsair.business.player.PlayerGear;
import fr.testudo.spacecorsair.business.player.PlayerInfo;
import fr.testudo.spacecorsair.engine.ObjectRegistry;
import java.util.List;

/** Ship-specific gear: only usable on its own ship, swapped automatically when the player changes ship. */
public class ModLock {

    public static PlayerShipSpec.Image requiredShip(SpaceObjectType t) {
        if (t == null) return null;
        String n = t.name();
        if (n.startsWith("alienBeamLaser")) return PlayerShipSpec.Image.ALIEN_UFO;
        if (n.startsWith("arwingBoltLaser")) return PlayerShipSpec.Image.ALIEN_RAT;
        if (n.startsWith("regentBeamLaser") || n.startsWith("regentHiveBay")) return PlayerShipSpec.Image.ALIEN_BLATTE;
        if (n.startsWith("megatronBattery") || n.startsWith("megatronSalvo")) return PlayerShipSpec.Image.TEST;
        if (n.startsWith(ModLance.BASE)) return ModLance.monolithImage();   // v43a-17 Phoenix Lance: Monolith only
        if (ModDev.isDev(t) && !ModDev.HULL.equals(n)) return devImage();   // the DEV kit belongs to the X-0 only
        return null;
    }

    /** Carriers (e.g. Nebula Moth) may mount the Regent Hive Bay. */
    private static boolean carrierOk(SpaceObjectType t) {
        try {
            PlayerInfo pi = ObjectRegistry.INSTANCE.game.playerInfo;
            return t != null && t.name().startsWith("regentHiveBay") && ModShips.isCarrier((PlayerShipSpec) pi.playerGear.playerShip.getGearSpec());
        } catch (Exception e) {
            return false;
        }
    }

    private static PlayerShipSpec.Image devImg;

    static PlayerShipSpec.Image devImage() {
        if (devImg == null) {
            try {
                devImg = PlayerShipSpec.Image.valueOf("MOD_DEV_PROTOTYPE");
            } catch (Exception e) {
                return null;
            }
        }
        return devImg;
    }

    public static String shipName(PlayerShipSpec.Image img) {
        if (img != null && img == devImage()) return "DEV Prototype X-0";
        if (img == PlayerShipSpec.Image.ALIEN_UFO) return "Banshee";
        if (img == PlayerShipSpec.Image.ALIEN_RAT) return "Arwing";
        if (img == PlayerShipSpec.Image.ALIEN_BLATTE) return "Regent";
        if (img == PlayerShipSpec.Image.TEST) return "Megatron";
        if (img != null && img == ModLance.monolithImage()) return "Monolith";
        return "?";
    }

    /** H2 slot rule; a ship's own signature gear always fits that ship. */
    static boolean fitsHull(SpaceObjectType t) {
        try {
            PlayerShipSpec.Image req = requiredShip(t);
            if (req != null && req == currentShip()) return true;
        } catch (Throwable th) {
            // no current ship: the slot rule decides
        }
        return ModV34.fits(t);
    }

    private static PlayerShipSpec.Image currentShip() {
        PlayerInfo pi = ObjectRegistry.INSTANCE.game.playerInfo;
        return ((PlayerShipSpec) pi.playerGear.playerShip.getGearSpec()).image;
    }

    private static void toast(String msg) {
        try {
            Toast.makeText(ObjectRegistry.INSTANCE.game.context, msg, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // not on a UI thread: skip the message, the gear logic still applies
        }
    }

    /** Hook at the start of PlayerInfo.equipObject. */
    public static boolean canEquip(SpaceObjectType t) {
        PlayerShipSpec.Image req = requiredShip(t);
        if (!fitsHull(t)) {
            toast(t.getLocalizedLabel() + ": " + ModLang.tr("Doesn't fit this slot") + " (" + ModV34.SLOT_NAMES[ModV34.weaponSize(t)] + ")");
            return false;
        }
        if (req == null || req == currentShip() || carrierOk(t)) {
            String lance = ModLance.equipBlock(t);   // v43a-17: and only at form V
            if (lance != null) { toast(lance); return false; }
            fitWarning(t);
            return true;
        }
        toast(t.getLocalizedLabel() + ModLang.tr(" can only be equipped on the ") + shipName(req) + ".");
        return false;
    }

    /** Weapon fit (2026-11-14, owner): equipping a laser that loses damage on this hull (H1) says so; the equip still goes ahead. */
    private static void fitWarning(SpaceObjectType t) {
        try {
            GearSpec g = t.getGearSpec();
            if (!(g instanceof fr.testudo.spacecorsair.business.loot.stuff.laser.LaserSpec)) return;
            String key = ModV34.gearHullKey();
            int st = ModV34.fitState(key, (fr.testudo.spacecorsair.business.loot.stuff.laser.LaserSpec) g);
            if (st == ModV34.FIT_OFF || st == ModV34.FIT_NEUTRAL) toast(t.getLocalizedLabel() + ": " + ModV34.fitLine(key, st));
        } catch (Throwable e) {
            // no warning
        }
    }

    /** Hook at the end of PlayerInfo.changeShip: fix the laser and missile slots for the new ship. */
    public static void onShipChanged() {
        try {
            PlayerInfo pi = ObjectRegistry.INSTANCE.game.playerInfo;
            PlayerGear gear = pi.playerGear;
            PlayerShipSpec.Image img = currentShip();
            if (img != null) ModArt.prefetch(img.shipTexture);   // new hull art decodes in the background (uploaded on return to flight)
            boolean changed = false;
            boolean stored = false;

            SpaceObjectType laser = pick(gear.laser, GearSpec.Type.LASER, img, SpaceObjectType.standardLaserLevel0);
            if (laser != gear.laser) {
                stored |= requiredShip(gear.laser) != null;
                swap(gear.laser, laser);
                gear.laser = laser;
                changed = true;
            }
            if (!fitsHull(gear.laser)) {
                // v34 (H2): the new hull's slots are too small for the fitted weapon
                swap(gear.laser, SpaceObjectType.standardLaserLevel0);
                gear.laser = SpaceObjectType.standardLaserLevel0;
                stored = true;
                changed = true;
            }
            SpaceObjectType shield = pick(gear.shield, GearSpec.Type.SHIELD, img, basicShield());
            if (shield != null && shield != gear.shield) {
                stored |= requiredShip(gear.shield) != null;
                swap(gear.shield, shield);
                gear.shield = shield;
                changed = true;
            }
            SpaceObjectType missile = pick(gear.missile, GearSpec.Type.MISSILE, img, SpaceObjectType.noMissileMod);
            if (missile != gear.missile) {
                stored |= requiredShip(gear.missile) != null;
                swap(gear.missile, missile);
                gear.missile = missile;
                changed = true;
            }
            if (changed && ObjectRegistry.INSTANCE.playerShip != null) {
                ObjectRegistry.INSTANCE.playerShip.applyGear();
                ObjectRegistry.INSTANCE.playerShip.updateRemainingMissiles();
                toast(stored ? ModLang.tr("Ship-specific gear moved to your hold and swapped for compatible gear.")
                             : shipName(img) + ModLang.tr(" gear equipped from your hold."));
            }
        } catch (Exception e) {
            // never block a ship change
        }
    }

    /** Keeps the equipped item when valid; prefers the new ship's own gear; else best compatible item in the hold. */
    private static SpaceObjectType pick(SpaceObjectType equipped, GearSpec.Type type, PlayerShipSpec.Image img, SpaceObjectType fallback) {
        Inventory inv = ObjectRegistry.INSTANCE.game.playerCurrentShipInventory;
        int lvl = ObjectRegistry.INSTANCE.game.playerInfo.level;
        PlayerShipSpec.Image req = requiredShip(equipped);
        if (((req != null && req == img) && ModLance.equipBlock(equipped) == null) || carrierOk(equipped)) {   // v43a-17: a Lance below form V comes off
            return equipped;
        }
        SpaceObjectType own = null;
        SpaceObjectType best = null;
        List<SpaceObject> list = inv.getContentAsList();
        for (SpaceObject so : list) {
            SpaceObjectType t = so.getSpaceObjectType();
            GearSpec g = t.getGearSpec();
            if (g == null || g.gearType != type || so.getQuantity() <= 0 || g.level > lvl) {
                continue;
            }
            PlayerShipSpec.Image r = requiredShip(t);
            if (r == img) {
                if (ModLance.tierOf(t) >= 0) continue;   // v43a-17: the Lance is never fitted automatically
                if (own == null || better(t, own)) own = t;
            } else if (r == null) {
                if (best == null || better(t, best)) best = t;
            }
        }
        if (own != null) {
            return own;
        }
        if (req == null) {
            return equipped; // normal gear stays put
        }
        return best != null ? best : fallback;
    }

    private static SpaceObjectType basicShield() {
        try {
            return SpaceObjectType.valueOf("basicShieldLevel1");
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean better(SpaceObjectType a, SpaceObjectType b) {
        int ra = a.getRarety().getRaretySort(), rb = b.getRarety().getRaretySort();
        if (ra != rb) return ra > rb;
        return a.getGearSpec().level > b.getGearSpec().level;
    }

    private static void swap(SpaceObjectType oldOne, SpaceObjectType newOne) {
        Inventory inv = ObjectRegistry.INSTANCE.game.playerCurrentShipInventory;
        if (oldOne != null) {
            inv.forceAddObject(SpaceObject.of(oldOne));
        }
        for (SpaceObject so : inv.getContentAsList()) {
            if (so.getSpaceObjectType() == newOne && so.getQuantity() > 0) {
                inv.removeObject(SpaceObject.of(newOne));
                break;
            }
        }
    }
}
