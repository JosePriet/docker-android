package fr.testudo.spacecorsair.mod;

/** Generated from the level builders: which station sells which item (shop inventories). */
final class ModSources {
    static final String[][] SHOP = {
        {"acidMisisleModLevel8", "Missile shop (Spartan HQ)"},
        {"agressorMissileModLevel9", "Missile shop (Spartan HQ)"},
        {"antimissileShieldLevel13", "Galactic jail (Eternity)"},
        {"argonLaserLevel10", "Laser shop (Spartan HQ)"},
        {"argonLaserLevel13", "Omicron goods station (Omicron Prime)"},
        {"basicShieldLevel1", "Space Station (Genesis)"},
        {"basicShieldLevel2", "Jimbo station (Ventohigh)"},
        {"basicShieldLevel3", "Space Station (Genesis)"},
        {"basicShieldLevel4", "Jimbo station (Ventohigh)"},
        {"callMobileSeller", "Arena official station (Heliostat), Omicron goods station (Omicron Prime), STATION_SHIPYARD_NAME (Ventohigh)"},
        {"cobaltLaserLevel13", "Omicron goods station (Omicron Prime)"},
        {"corrosifMissileMod11", "Trade station (Lost Paradise), Smuggler station (Solar Field)"},
        {"decentLaserLevel3", "Space Station (Genesis)"},
        {"decentLaserLevel5", "Replex laser inc (Ventohigh)"},
        {"decentLaserLevel8", "Replex laser inc (Ventohigh)"},
        {"decentShieldLevel0", "Space Station (Genesis)"},
        {"decentShieldLevel2", "Jimbo station (Ventohigh)"},
        {"decentShieldLevel5", "Jimbo station (Ventohigh)"},
        {"diamond", "Mining Corp (Genesis), Mining Corp (Ore Belt)"},
        {"diamondShieldLevel15", "Shield shop (Spartan HQ)"},
        {"dilmaxLaser8", "Laser shop (Spartan HQ)"},
        {"energyCell", "Pilot Licence Station (Galactic Speedway), Trade station (Heliostat), Trade station (Solar Field), Trade station (Tutorial)"},
        {"exceptionalLaserLevel5", "Smuggler station (Pirate Bay)"},
        {"exceptionalLaserLevel7", "Replex laser inc (Ventohigh)"},
        {"exceptionalLaserLevel9", "Laser shop (Spartan HQ)"},
        {"extraBooster", "STATION_SHIPYARD_NAME (Ventohigh)"},
        {"extraHyperdriveEngine", "STATION_SHIPYARD_NAME (Ventohigh)"},
        {"fastReloadShieldLevel2", "Space Station (Genesis)"},
        {"fastReloadShieldLevel6", "Jimbo station (Ventohigh)"},
        {"fastReloadShieldLevel9", "Laser shop (Spartan HQ)"},
        {"galiumLaserLevel12", "Omicron goods station (Omicron Prime)"},
        {"goodBooster", "General store (Highway), STATION_SHIPYARD_NAME (Ventohigh)"},
        {"goodHyperdriveEngine", "STATION_SHIPYARD_NAME (Ventohigh)"},
        {"healerShieldLevel11", "Omicron goods station (Omicron Prime)"},
        {"healerShieldLevel3", "Jimbo station (Ventohigh)"},
        {"healerShieldLevel8", "Shield shop (Spartan HQ)"},
        {"hydraRoquetteLevel0", "SPARTAN_MISSILE (Ventohigh)"},
        {"hydraRoquetteLevel6", "Missile shop (Spartan HQ)"},
        {"hydraRoquetteLevel8", "Missile shop (Spartan HQ)"},
        {"instaRepair", "Arena official station (Heliostat), Smuggler station (Pirate Bay), Trade station (Solar Field), STATION_SHIPYARD_NAME (Ventohigh)"},
        {"iridiumLaserLevel10", "Laser shop (Spartan HQ)"},
        {"jaspinBite5", "Smuggler station (Pirate Bay)"},
        {"malachite", "Mining Corp (Genesis), Mining Corp (Ore Belt)"},
        {"mirrorShieldLevel9", "Shield shop (Spartan HQ)"},
        {"missile", "Arena official station (Heliostat), Trade station (Lost Paradise), Smuggler station (Pirate Bay), Smuggler station (Solar Field), Missile shop (Spartan HQ), SPARTAN_MISSILE (Ventohigh)"},
        {"mosquitoMissileLevel0", "SPARTAN_MISSILE (Ventohigh)"},
        {"mosquitoMissileLevel3", "SPARTAN_MISSILE (Ventohigh)"},
        {"mosquitoMissileLevel6", "Missile shop (Spartan HQ), SPARTAN_MISSILE (Ventohigh)"},
        {"mosquitoMissileLevel9", "Missile shop (Spartan HQ)"},
        {"omegaMissileModLevel12", "Trade station (Lost Paradise)"},
        {"percuteurMissileModLevel14", "Trade station (Lost Paradise)"},
        {"percuteurMissileModLevel5", "SPARTAN_MISSILE (Ventohigh)"},
        {"percuteurMissileModLevel6WithCrit", "Smuggler station (Pirate Bay)"},
        {"periousShieldLevel13", "Arena official station (Heliostat), Smuggler station (Solar Field)"},
        {"pilotShield", "Pilot Licence Station (Galactic Speedway)"},
        {"pilotShieldAdv", "Pilot Licence Station (Galactic Speedway)"},
        {"ruby", "Mining Corp (Genesis), Mining Corp (Ore Belt), Trade station (Tutorial)"},
        {"solitaireLaserLevel12", "Smuggler station (Solar Field)"},
        {"souteIncrease300", "STATION_SHIPYARD_NAME (Ventohigh)"},
        {"spartanBlockerLevel6", "Shield shop (Spartan HQ), Jimbo station (Ventohigh)"},
        {"spartanBlockerLevel8", "Shield shop (Spartan HQ)"},
        {"spartanBlockerPlusLevel6", "Smuggler station (Pirate Bay)"},
        {"standardFastLaserLevel3", "Space Station (Genesis)"},
        {"standardFastLaserLevel4", "Replex laser inc (Ventohigh)"},
        {"standardLaserLevel1WithCrit", "Space Station (Genesis)"},
        {"standardLaserLevel2", "Replex laser inc (Ventohigh)"},
        {"standardLaserLevel3", "Replex laser inc (Ventohigh)"},
        {"standardLaserLevel4", "Replex laser inc (Ventohigh)"},
        {"standardSlowLaserLevel6", "Replex laser inc (Ventohigh)"},
        {"torpedoMissileLevel3", "SPARTAN_MISSILE (Ventohigh)"},
        {"torpedoMissileLevel6", "Smuggler station (Pirate Bay), Missile shop (Spartan HQ)"},
        {"torpedoMissileLevel9", "Missile shop (Spartan HQ)"},
        {"tungstenMissileModLevel9", "Trade station (Lost Paradise)"},
        {"warriorShieldLevel5", "Smuggler station (Pirate Bay)"},
        {"water", "General store (Highway)"},
        {"xenonShieldLevel10", "Shield shop (Spartan HQ)"},
        {"xenonShieldLevel12", "Omicron goods station (Omicron Prime)"},
    };

    static String shop(String typeName) {
        for (String[] r : SHOP) if (r[0].equals(typeName)) return realNames(r[1]);
        return null;
    }

    /** Audit A8 (owner): the two builder constants show as the stations' real names, EN and ES. */
    static String realNames(String s) {
        if (s.indexOf("STATION_SHIPYARD_NAME") >= 0) s = s.replace("STATION_SHIPYARD_NAME", ModLang.tr("Shipyard"));
        if (s.indexOf("SPARTAN_MISSILE") >= 0) {
            String m;
            try { m = fr.testudo.spacecorsair.business.world.UniverseName.SPARTAN_MISSILE; } catch (Throwable t) { m = null; }
            s = s.replace("SPARTAN_MISSILE", m != null && m.length() > 0 ? m : ModLang.tr("Spartan missiles"));
        }
        return s;
    }
}
