package fr.testudo.spacecorsair.mod;

import android.content.SharedPreferences;
import fr.testudo.spacecorsair.business.Element;
import fr.testudo.spacecorsair.business.ennemis.Ennemis;
import fr.testudo.spacecorsair.business.player.PlayerShip;
import fr.testudo.spacecorsair.business.world.civil.GuardianCivilShip;
import fr.testudo.spacecorsair.display.Drawable;
import fr.testudo.spacecorsair.display.Texture;
import fr.testudo.spacecorsair.engine.ObjectRegistry;
import fr.testudo.spacecorsair.engine.Vector2;
import java.util.ArrayList;

/**
 * v30 wrecks. Cruiser-size hulls and bigger break into 2-3 pieces cut from their own sprite when destroyed (burnt
 * colour, torn hot edges along the cuts, venting, sparks). Pieces are real elements: they drift, collide with ships and
 * asteroids, and anyone can shoot them apart; only the player's kills roll loot (ModLoot.fromWreck).
 * - Enemy wrecks stay for the whole visit of the sector (oldest removed past MAX pieces).
 * - The player's own hull breaks up during the 4 s before the respawn screen; it is visual only and then removed.
 * - Alien hulls dissolve into spores instead (no pieces).
 * - Derelict sites (ModDerelict) use the same pieces, pre-broken and still.
 * - v33: hulls with hand-drawn wreck art (wreck_<art>_a/_b[/_c], same canvas as the hull sprite, a = bow) break into those
 *   pieces; the others keep the cut sprite, scorched toward the cuts (flat dark gradient + char marks). Pieces are heavy (mass from the
 *   original hull size) and only drift: hits and rams barely move them.
 * - v37: blasts (missiles, mines) keep 5% of their push; motion from hits and rams brakes out within 2 s and is capped at
 *   10 u/s on top of the slow break-apart drift. Alien beams (UFO, AlienBlatte) stop at the first piece on their line.
 */
public final class ModWreck extends Element {
    // ------------------------------------------------------------------ piece
    Texture tex;
    String art;                 // on-demand art (derelicts) when tex is null
    float u0, v0, u1, v1;       // sprite rectangle of this piece
    float w, h;                 // world size of the piece
    boolean cutTop, cutBottom;  // torn edges (v0 side / v1 side)
    boolean visualOnly;
    boolean derelict;
    int srcLevel, srcClass;     // loot inputs: level and size class (0 small .. 3 capital)
    boolean srcElite, srcBoss;
    long born, lifeMs;          // visualOnly pieces fade out
    float tint = 0.62f;
    int derelictSite = -1;
    boolean[] group;            // shared by the pieces of one hull: loot rolls once per hull
    boolean preDrawn;           // v33: hand-drawn wreck art (already burnt and torn: no tint, no edge strip, no char)
    boolean poi;                // v35: wreck field / kept flagship wreck: never pushed out by newer wrecks
    String lootKey;             // v35: kept flagship wreck record or wreck-field sector; ModSector.looted marks it when the hull is looted
    int pieceIdx = -1;          // v35: piece index inside a kept flagship wreck record (ModSector.pieceShot)
    boolean husk;               // v35: a small hull's husk (pushed out first)
    long fadeMs;                // v35: fades after this long (0 = stays for the visit)
    private float lastVx, lastVy;
    private float baseVx, baseVy;   // v37: the slow break-apart drift (stock friction only); speed minus this = motion from hits
    float blastVx, blastVy;         // v37: blast pushes since the last frame (ModWreck.blastPush)
    private final Vector2 phys = new Vector2(), vis = new Vector2();
    private final ModFx.Sprite spr = new ModFx.Sprite();
    private final ModFx.Sprite burnSpr = new ModFx.Sprite();
    private final float[] burnA = new float[2];   // v33 burn alpha at the v0 / v1 edge
    private float[] scorch;
    private float scorchSize;
    private long nextVent;

    ModWreck() {
        hasSpeedDeperdition = true;
        speedDeperditionfactor = 1.0015f;
        drawOnRadar = false;
        mass = 6.0f;
        objectName = "Wreck";
        born = System.currentTimeMillis();
        nextVent = born + (long) (Math.random() * 1500);
    }

    @Override
    public Drawable getDrawableObject() {
        Texture t = tex != null ? tex : ModArt.ready(art);
        if (t == null) return null;
        spr.myTexture = t;
        spr.w = w;
        spr.h = h;
        spr.u0 = u0; spr.v0 = v0; spr.u1 = u1; spr.v1 = v1;
        spr.additive = false;
        return spr;
    }

    @Override
    public Drawable getMiniDrawableObject() {
        return null;
    }

    @Override
    public Vector2 getPhysicDimension() {
        return phys;
    }

    /** Culling by the drawn size: long pieces would pop at the screen edges with the (smaller) physic circle. */
    @Override
    public Vector2 getDimToTestIfVisibleOnScreen() {
        float m = Math.max(w, h);
        vis.set(m, m);
        return vis;
    }

    @Override
    public boolean isColidable() {
        return !visualOnly && super.isColidable();
    }

    /** v33: the hull's mass from its drawn size (a cruiser ~200, a flagship ~1100). */
    static float massFor(float size) {
        return Math.max(20.0f, size * size / 2000.0f);
    }

    static final float MAX_DRIFT = 0.4f;   // speed units are per 10 ms: 40 world units a second at most

    static final float BLAST_PUSH = 0.05f;   // v37 owner: blasts keep 5% of the stock push (v33: 30%, like rams)
    static final float HIT_MAX = 0.1f;       // v37 owner: motion from hits capped at 10 u/s
    static final float HIT_TAU = 2000.0f / 3; // v37: hit motion decays to 5% in 2 s ...
    static final long HIT_STOP = 2000;       // ... and is set to 0 once 2 s pass without a new push (owner: gone within 2 s)
    private long hitAge;                     // ms since the last push
    long restTest;                           // v37 test: blast time (ModDev corsair_blastwreck), logged when the hit motion is 0
    private static int beamLogs, beamCalls;

    /** v33: whatever pushed the piece since the last frame (hits, rams, blasts) only moves it a little. */
    @Override
    public void doPhysic(long j) {
        float dx = speed.x - lastVx, dy = speed.y - lastVy;
        hitAge = dx != 0 || dy != 0 ? 0 : hitAge + j;
        // v37: the blast share keeps 5%; projectile hits (already 10% in applyRebound) and rams keep 30% as in v33
        float cx = damp(dx, blastVx), cy = damp(dy, blastVy);
        // a push against the drift (a bounce off an asteroid or a ship) slows the drift itself, down to 0; the rest is hit motion
        float b2 = baseVx * baseVx + baseVy * baseVy;
        float q = b2 > 0 ? (cx * baseVx + cy * baseVy) / b2 : 0;
        if (q < 0) {
            q = Math.max(q, -1);
            baseVx *= 1 + q;
            baseVy *= 1 + q;
        }
        hit[0] = lastVx + cx - baseVx;
        hit[1] = lastVy + cy - baseVy;
        blastVx = blastVy = 0;
        brake(hit, j, hitAge);
        if (restTest > 0 && hit[0] == 0 && hit[1] == 0) {
            ModDev.ev("wreckrest", "blast motion stopped after " + (System.currentTimeMillis() - restTest) + " ms");
            restTest = 0;
        }
        speed.set(baseVx + hit[0], baseVy + hit[1]);
        float v2 = speed.x * speed.x + speed.y * speed.y;
        if (v2 > MAX_DRIFT * MAX_DRIFT) {
            float k = MAX_DRIFT / (float) Math.sqrt(v2);
            speed.multiply(k);
            baseVx *= k;          // keep the drift's share in step, so the cap does not bend it
            baseVy *= k;
        }
        super.doPhysic(j);
        // the break-apart drift slows with the stock friction (Element.doPhysic divides the speed by this each frame)
        float f = speedDeperditionfactor + (speedDeperditionfactor - 1) * j / 160.0f;
        baseVx /= f;
        baseVy /= f;
        lastVx = speed.x;
        lastVy = speed.y;
        long age = System.currentTimeMillis() - born;
        if (visualOnly && age > lifeMs || fadeMs > 0 && age > fadeMs) {
            vanish();
        }
    }

    private final float[] hit = new float[2];

    /** v37: the kept part of a velocity change d whose blast share is b: blasts BLAST_PUSH, everything else 30% (v33). */
    static float damp(float d, float b) {
        return (d - b) * 0.3f + b * BLAST_PUSH;
    }

    /** v37: motion from hits (h, speed units per 10 ms) after j ms, age ms after the last push: capped at HIT_MAX, decays with HIT_TAU, 0 from HIT_STOP. */
    static void brake(float[] h, long j, long age) {
        float v = (float) Math.sqrt(h[0] * h[0] + h[1] * h[1]);
        if (v == 0) return;
        float n = age >= HIT_STOP ? 0 : Math.min(v, HIT_MAX) * (float) Math.exp(-Math.max(0, j) / HIT_TAU);
        h[0] *= n / v;
        h[1] *= n / v;
    }

    /** v37 smali hook (Missile.applyRadiusDamage, Mine.applyRadiusDamage): the stock blast push, marked on wreck pieces. */
    public static void blastPush(Element e, Vector2 v) {
        e.speed.add(v);
        if (e instanceof ModWreck) {
            ModWreck w = (ModWreck) e;
            w.blastVx += v.x;
            w.blastVy += v.y;
        }
    }

    /**
     * v37 smali hook (UfoAlienShip / AlienBlatte beam: damage, impact sparks and drawing): the first wreck piece crossing the
     * beam from the shooter to its target takes the beam instead; otherwise the target.
     */
    public static Element beamTarget(Element shooter, Element target) {
        if (beamCalls < 3) { beamCalls++; ModDev.ev("beamwreck", "beam hook " + (shooter == null ? "null" : shooter.getClass().getSimpleName()) + " -> " + (target == null ? "null" : target.getClass().getSimpleName()) + " live pieces=" + live.size()); }
        if (shooter == null || target == null || target.removed || target instanceof ModWreck) return target;
        try {
            Element best = target;
            float bt = 2;
            float ax = shooter.position.x, ay = shooter.position.y;
            for (int i = 0, n = live.size(); i < n; i++) {
                ModWreck w = live.get(i);
                if (w.removed || w.visualOnly) continue;
                float t = segHit(ax, ay, target.position.x, target.position.y, w.position.x, w.position.y, w.phys.x / 2);
                if (t >= 0 && t < bt) { bt = t; best = w; }
            }
            if (best != target && beamLogs < 5) { beamLogs++; ModDev.ev("beamwreck", shooter.getClass().getSimpleName() + " beam stopped on a wreck piece"); }
            return best;
        } catch (Throwable t) {
            return target;   // the stock beam always works
        }
    }

    /** Where (0..1 along a->b) the segment first meets the circle (c, r); -1 when it misses. */
    static float segHit(float ax, float ay, float bx, float by, float cx, float cy, float r) {
        float dx = bx - ax, dy = by - ay, fx = ax - cx, fy = ay - cy;
        float A = dx * dx + dy * dy, B = 2 * (fx * dx + fy * dy), C = fx * fx + fy * fy - r * r;
        if (C <= 0) return 0;                // the shooter is inside the piece
        if (A == 0) return -1;
        float D = B * B - 4 * A * C;
        if (D < 0) return -1;
        float t = (-B - (float) Math.sqrt(D)) / (2 * A);
        return t >= 0 && t <= 1 ? t : -1;
    }

    /** v33: a projectile hit gives (almost) no push. */
    @Override
    protected float applyRebound(Element o, int n) {
        if (!(o instanceof fr.testudo.spacecorsair.business.projectiles.Projectile)) return super.applyRebound(o, n);
        float vx = speed.x, vy = speed.y;
        float r = super.applyRebound(o, n);
        speed.set(vx + (speed.x - vx) * 0.1f, vy + (speed.y - vy) * 0.1f);
        return r;
    }

    /** v37 owner: kept flagship/titan wreck pieces and derelict pieces hold high-value loot; only the player (or a drone) can finish them. */
    boolean playerOnly() {
        return derelict || lootKey != null && lootKey.startsWith("keep:");
    }

    @Override
    public void applyDamage(float f, Element sender, fr.testudo.spacecorsair.business.projectiles.Projectile p) {
        if (playerOnly() && !(sender != null && (sender.isPlayer || Mod.isDrone(sender)))) {
            f = Math.min(f, life - 1);   // enemies, asteroids and blasts from others can wear it down but never break it
            if (f <= 0) return;
        }
        super.applyDamage(f, sender, p);
    }

    private void vanish() {
        live.remove(this);   // v37: always, so the wreck cap loop in add() moves on even for an already removed piece
        if (removed) return;
        removed = true;
        if (visualOnly) ObjectRegistry.INSTANCE.game.currentLevel.toDeleteDrawOnly.add(this);
        else ObjectRegistry.INSTANCE.game.currentLevel.toDelete.add(this);
    }

    private static final Vector2 a = new Vector2(), b = new Vector2();

    @Override
    public void registerYourselfToDrawQueue() {
        Drawable d = getDrawableObject();
        if (d == null) return;
        long now = System.currentTimeMillis();
        float alpha = 1.0f;
        long span = visualOnly ? lifeMs : fadeMs;
        if (span > 0) {
            float k = (now - born) / (float) Math.max(1, span);
            alpha = k > 0.75f ? Math.max(0, 1 - (k - 0.75f) / 0.25f) : 1.0f;
        }
        float hp = maxLife > 0 ? life / maxLife : 1;
        boolean burn = !preDrawn && !derelict && (cutTop || cutBottom);
        float tn = preDrawn ? 1.0f : burn ? Math.max(tint, 0.8f) : tint;   // the burn does the darkening near the cuts
        ObjectRegistry.INSTANCE.renderQueue.addToWaitingQueue(position, false, spr, spin, false, alpha, tn, tn * 0.94f, tn * 0.9f);
        if (burn) {
            // scorched toward the cuts: the piece's silhouette again in near-black, fading out away from the break
            burnSpr.myTexture = spr.myTexture;
            burnSpr.w = w; burnSpr.h = h;
            burnSpr.u0 = u0; burnSpr.v0 = v0; burnSpr.u1 = u1; burnSpr.v1 = v1;
            burnSpr.additive = false;
            burnSpr.flat = true;
            burnSpr.edgeA = burnA;
            ObjectRegistry.INSTANCE.renderQueue.addToWaitingQueue(position, false, burnSpr, spin, false, alpha * 0.85f, 0.07f, 0.05f, 0.04f);
            if (scorch == null) {
                scorch = new float[4];
                for (int i = 0; i < 2; i++) {               // two char marks on the hull's real width near a cut
                    boolean top = cutTop && (!cutBottom || i == 0);
                    float vv = top ? v0 + (v1 - v0) * 0.12f : v1 - (v1 - v0) * 0.12f;
                    float x0 = 0.4f, x1 = 0.6f;
                    if (ModArt.span(spr.myTexture, Math.min(0.999f, Math.max(0, vv)), sp) != null) { x0 = sp[0]; x1 = sp[1]; }
                    scorch[2 * i] = (x0 + (x1 - x0) * (0.3f + 0.4f * (float) Math.random()) - 0.5f) * w;
                    scorch[2 * i + 1] = (top ? -0.38f : 0.38f) * h;
                    scorchSize = Math.max(scorchSize, (x1 - x0) * w * 0.35f);
                }
            }
            for (int i = 0; i < 2; i++) {
                b.set(scorch[2 * i], scorch[2 * i + 1]).applyRotatation(Math.toRadians(spin)).add(position);
                float ss = Math.min(scorchSize, h * 0.5f);
                ModFx.spr("fx_scorch", b.x, b.y, ss, ss, spin + i * 97, 1, 1, 1, 0.8f * alpha, false);
            }
        }
        // torn hot edges along the cuts (cool down over ~20 s)
        float heat = derelict ? 0.25f : Math.max(0.25f, 1.0f - (now - born) / 20000.0f);
        Texture et = preDrawn ? null : ModArt.ready("wreck_edge");
        if (et != null) {
            if (cutTop) edge(et, v0, -h / 2, spin, heat, alpha, d.myTexture);
            if (cutBottom) edge(et, v1, h / 2, spin + 180, heat, alpha, d.myTexture);
        }
        // venting and sparks from the breach while hot, smoke when shot up
        if (now > nextVent && !derelict) {
            nextVent = now + 500 + (long) (Math.random() * 1600 / Math.max(0.3f, heat));
            float ly = cutTop ? -h / 2 : h / 2;
            b.set((float) (Math.random() - 0.5) * w * 0.6f, ly).applyRotatation(Math.toRadians(spin)).add(position);
            ModLive.fx("fx_vent_sheet", 4, 16, b.x, b.y, w * 0.3f, 900, 0.8f, 0.85f, 0.9f, true);
            if (Math.random() < heat) ModLive.fx("fx_sparks_sheet", 4, 16, b.x, b.y, w * 0.22f, 420, 1.0f, 0.8f, 0.45f, true);
        }
        if (hp < 0.5f && Math.random() < 0.06) {
            b.set((float) (Math.random() - 0.5) * w * 0.5f, (float) (Math.random() - 0.5) * h * 0.5f).applyRotatation(Math.toRadians(spin)).add(position);
            ModLive.fx("fx_smoke_sheet", 4, 16, b.x, b.y, w * 0.35f, 1500, 0.45f, 0.45f, 0.45f, true);
        }
    }

    private static final float[] sp = new float[2];

    /** Torn hot edge along a cut, as wide as the hull's visible row there (texture row profile). */
    private void edge(Texture et, float v, float ly, float rot, float heat, float alpha, Texture src) {
        float x0 = 0.3f, x1 = 0.7f;
        if (ModArt.span(src, Math.min(0.999f, Math.max(0, v)), sp) != null) { x0 = sp[0]; x1 = sp[1]; }
        float ew = (x1 - x0) * w;
        if (ew < 8) return;
        float lx = ((x0 + x1) / 2 - 0.5f) * w;
        float eh = Math.max(14.0f, Math.min(ew * 0.18f, w * 0.06f));
        a.set(lx, ly).applyRotatation(Math.toRadians(spin)).add(position);
        ModFx.sprTex(et, a.x, a.y, ew * 1.04f, eh, rot, 1, 0.75f + 0.25f * heat, 0.6f + 0.4f * heat, alpha, false, 0, 0, 1, 1);
    }

    @Override
    public void onDestroyed(boolean z) {
        if (removed) return;
        try {
            float s = Math.max(w, h);
            ModLive.fx("fx_explosion_big_sheet", 8, 64, position.x, position.y, s * 1.3f, 1100, 1.0f, 0.75f, 0.45f, true);
            debris(position, speed, s, 6);
            ObjectRegistry.INSTANCE.soundManager.playRandomExplode();
            if (z) ModLoot.fromWreck(this);
            if (derelict) ModDerelict.onPieceDestroyed(this, z);
            if (pieceIdx >= 0 && lootKey != null) ModSector.pieceShot(lootKey, pieceIdx);   // owner 2026-10-22: shot pieces stay gone and empty
        } catch (Throwable t) {
            // a wreck always goes away
        }
        live.remove(this);
        super.onDestroyed(false);
    }

    // ------------------------------------------------------------------ spawning
    static final ArrayList<ModWreck> live = new ArrayList<ModWreck>();
    static final int MAX = 36;

    /** v35 (I4) wreck lifetime by size class: husks 2 min, cruiser wrecks 5 min, battleship-size and bigger the whole visit (0). */
    public static long lifeMs(int sizeClass) {
        if (sizeClass <= 1) return 120000;
        if (sizeClass == 2) return 300000;
        return 0;
    }

    /** Size class from the physic diameter: 0 small, 1 medium, 2 cruiser-size, 3 battleship-size and bigger. */
    static int sizeClass(Element e) {
        if (ModTitan.isTitanClass(e) || ModCapitals.cap(e) != null) return 3;
        return sizeClassOf(e.getPhysicDimension() == null ? 0 : e.getPhysicDimension().x);
    }

    /** Physic diameter is 0.62-0.7 x hull size: frigates up to ~65, destroyers ~140, cruisers/battlecruisers ~320, battleships 370+. */
    public static int sizeClassOf(float p) {
        if (p < 70) return 0;
        if (p < 145) return 1;
        if (p < 340) return 2;
        return 3;
    }

    private static int playerClass(PlayerShip ps) {
        ModShips.Hull h = ModShips.hullFor(ps.shipSpec);
        int c = h != null ? h.cls : ModShips.originalClass(ps.shipSpec);
        if (c == ModShips.TITAN || c == ModShips.CAPITAL) return 3;
        if (c == ModShips.CRUISER || c == ModShips.BATTLECRUISER || c == ModShips.BATTLESHIP || c == ModShips.INDUSTRIAL) return 2;
        return c == ModShips.DESTROYER ? 1 : 0;
    }

    /** Smali hook at the start of Element.onDestroyed (every element, every cause). */
    public static void onDestroyed(Element e, boolean z) {
        if (e == null || e.removed || e instanceof ModWreck || e instanceof fr.testudo.spacecorsair.business.projectiles.Projectile) return;
        try {
            if (ObjectRegistry.INSTANCE.game.mapMode) return;
            if (e.isPlayer && e instanceof PlayerShip) {
                PlayerShip ps = (PlayerShip) e;
                if (ps.shipSpec == null) return;
                Drawable d = ps.getDrawableObject();
                int cls = playerClass(ps);
                String art = d == null ? null : ModArt.artOf(d.myTexture);
                if (ModLive.alienArt(art)) { spores(e, d); return; }
                if (cls >= 2 && d != null) breakUp(e, d, cls, true, 3800);
                else if (d != null) ModLive.fx("vfx_explosion_sheet", 8, 64, e.position.x, e.position.y, ModLive.sizeOf(d) * 1.6f, 900, 1, 0.8f, 0.5f, true);
                return;
            }
            boolean ship = e instanceof Ennemis || e instanceof fr.testudo.spacecorsair.business.world.civil.CivilShip;
            if (!ship || Mod.isDrone(e)) return;
            Drawable d = e.getDrawableObject();
            if (d == null || d.myTexture == null) return;
            String art = ModArt.artOf(d.myTexture);
            if (ModLive.alienArt(art) || e instanceof fr.testudo.spacecorsair.business.ennemis.AlienRat
                || e instanceof fr.testudo.spacecorsair.business.ennemis.UfoAlienShip) {
                spores(e, d);
                if (!(sizeClass(e) >= 2)) return;
                return;          // living hulls dissolve: no metal pieces
            }
            int cls = sizeClass(e);
            if (cls < 2) {
                if (cls == 1) husk(e, d);   // owner 2026-10-22: frigates leave nothing (the kill's own loot chance only); destroyers a husk
                return;
            }
            boolean elite = e instanceof Ennemis && ((Ennemis) e).elite;
            boolean boss = ModBoss.kindOf(e) >= 0;
            ModCapitals.Cap cap = ModCapitals.cap(e);
            ModWreck[] made = breakUpArt(e, d, cap != null && cap.f != null ? (cap.police ? "pol_wreck_cap_" : "wreck_cap_") + cap.f.key : art == null ? null : "wreck_" + art);
            if (made == null) made = breakUp(e, d, cls, false, 0);
            if (made != null) {
                for (ModWreck w : made) {
                    if (w == null) continue;
                    w.fadeMs = lifeMs(cls);
                    w.srcLevel = e.level;
                    w.srcClass = cls;
                    w.srcElite = elite;
                    w.srcBoss = boss;
                }
                if ((cap != null || ModTitan.isTitanClass(e)) && (cap == null || !cap.police)) ModSector.persist(made, e.level, boss);   // v35: kept for the next visits (v42: not police titans)
            }
        } catch (Throwable t) {
            // the stock death always happens
        }
    }

    /** v33 piece bands of the hand-drawn art (v ranges, overlapping so the jagged break is never clipped). */
    private static final float[][] BANDS2 = {{0, 0.56f}, {0.44f, 1}};
    private static final float[][] BANDS3 = {{0, 0.4f}, {0.3f, 0.7f}, {0.6f, 1}};

    /**
     * Hand-drawn wreck pieces <prefix>_a, _b (and _c): full-canvas images on the hull sprite's canvas, a = bow. Each piece
     * shows its band of the canvas at the hull's own anchor. Null when the art does not exist (cut the sprite instead).
     */
    private static ModWreck[] breakUpArt(Element e, Drawable d, String prefix) {
        if (prefix == null || ModArt.lazyTex(prefix + "_a") == null || ModArt.lazyTex(prefix + "_b") == null) return null;
        int n = ModArt.lazyTex(prefix + "_c") != null ? 3 : 2;
        float W, H;
        if (d instanceof ModFx.Sprite) { W = ((ModFx.Sprite) d).w; H = ((ModFx.Sprite) d).h; }
        else if (d.dimensions != null) { W = d.dimensions.x; H = d.dimensions.y; }
        else return null;
        float s = Math.max(W, H);
        ModLive.fx("fx_explosion_big_sheet", 8, 64, e.position.x, e.position.y, s * 1.35f, 1300, 1.0f, 0.8f, 0.5f, true);
        debris(e.position, e.speed, s, 8);
        boolean[] grp = new boolean[1];
        float[][] bands = n == 3 ? BANDS3 : BANDS2;
        ModWreck[] out = new ModWreck[n];
        for (int i = 0; i < n; i++) {
            ModWreck w = new ModWreck();
            w.group = grp;
            w.art = prefix + "_" + (char) ('a' + i);
            w.preDrawn = true;
            w.tint = 1.0f;
            w.u0 = 0; w.u1 = 1;
            w.v0 = bands[i][0]; w.v1 = bands[i][1];
            w.cutTop = i > 0;                     // vents at the break
            w.cutBottom = i < n - 1;
            w.w = W;
            w.h = H * (w.v1 - w.v0);
            place(w, e, H, s);
            out[i] = w;
            add(w);
        }
        return out;
    }

    /** Position, slow break-apart drift and mass of a piece cut from the hull e (band v0..v1 of a sprite H high). */
    private static void place(ModWreck w, Element e, float H, float size) {
        float ly = ((w.v0 + w.v1) / 2 - 0.5f) * H;
        a.set(0, ly).applyRotatation(Math.toRadians(e.spin));
        w.position.setSameAs(e.position).add(a);
        w.spin = e.spin;
        // apart along the long axis, plus a little of the hull's own drift and a slow tumble; heavier hulls drift slower
        float push = (0.25f + (float) Math.random() * 0.25f) * Math.min(1.0f, 400.0f / Math.max(400.0f, size) + 0.3f);
        float len = Math.max(1, (float) Math.sqrt(a.x * a.x + a.y * a.y));
        w.speed.set(e.speed.x * 0.3f + a.x / len * push, e.speed.y * 0.3f + a.y / len * push);
        float v2 = w.speed.x * w.speed.x + w.speed.y * w.speed.y;
        if (v2 > MAX_DRIFT * MAX_DRIFT) w.speed.multiply(MAX_DRIFT / (float) Math.sqrt(v2));
        w.spinSpeed = (float) (Math.random() - 0.5) * 0.05f;
        w.phys.set(Math.min(w.w, w.h) * 0.8f, Math.min(w.w, w.h) * 0.8f);
        w.mass = massFor(size);
        w.maxLife = Math.max(300.0f, e.maxLife * 0.2f);
        w.life = w.maxLife;
        w.level = e.level;
        w.updateSapCoords();
    }

    /** Metal chunks (debris_sheet cells) flung out from a point. */
    static void debris(Vector2 at, Vector2 v, float s, int n) {
        for (int i = 0; i < n; i++) {
            double ang = Math.random() * Math.PI * 2;
            float sp = s * (0.3f + (float) Math.random() * 0.6f);
            ModLive.chunk("debris_sheet", 4, 4, (int) (Math.random() * 16), at.x, at.y, s * (0.1f + (float) Math.random() * 0.1f), 1800,
                v.x * 100 + (float) Math.cos(ang) * sp, v.y * 100 + (float) Math.sin(ang) * sp);
        }
    }

    /** Spore dissolve for living hulls (no explosion debris). */
    static void spores(Element e, Drawable d) {
        float s = ModLive.sizeOf(d);
        ModLive.fx("fx_spore_sheet", 4, 16, e.position.x, e.position.y, s * 1.5f, 1300, 0.65f, 1.0f, 0.55f, true);
        ModLive.fx("fx_ichor_sheet", 4, 16, e.position.x, e.position.y, s * 0.9f, 800, 0.6f, 0.3f, 1.0f, true);
    }

    /** Cut the hull's sprite across its long axis into 2 (3 for capitals) pieces flying apart. */
    static ModWreck[] breakUp(Element e, Drawable d, int cls, boolean visualOnly, long lifeMs) {
        Texture t = d.myTexture;
        // audit B15 (owner): a hull whose lazy texture is not uploaded yet still breaks up (the sprite uploads it on draw)
        if (t == null || (t.name <= 0 && !(t instanceof ModArt.Lazy))) return null;
        float W, H;
        if (d instanceof ModFx.Sprite) { W = ((ModFx.Sprite) d).w; H = ((ModFx.Sprite) d).h; }
        else { W = d.dimensions.x; H = d.dimensions.y; }
        int n = cls >= 3 ? 3 : 2;
        float[] cuts = n == 2 ? new float[]{0, 0.44f + (float) Math.random() * 0.12f, 1}
            : new float[]{0, 0.3f + (float) Math.random() * 0.08f, 0.6f + (float) Math.random() * 0.08f, 1};
        ModWreck[] out = new ModWreck[n];
        boolean[] grp = new boolean[1];
        float s = Math.max(W, H);
        ModLive.fx("fx_explosion_big_sheet", 8, 64, e.position.x, e.position.y, s * 1.35f, 1300, 1.0f, 0.8f, 0.5f, true);
        debris(e.position, e.speed, s, 8);
        for (int i = 0; i < n; i++) {
            ModWreck w = new ModWreck();
            w.group = grp;
            w.tex = t;
            w.u0 = 0; w.u1 = 1;
            w.v0 = cuts[i]; w.v1 = cuts[i + 1];
            w.cutTop = i > 0;
            w.cutBottom = i < n - 1;
            w.w = W;
            w.h = H * (w.v1 - w.v0);
            w.burnA[0] = w.cutTop ? 0.9f : 0.0f;          // burnt black at a cut, the far end untouched
            w.burnA[1] = w.cutBottom ? 0.9f : 0.0f;
            place(w, e, H, s);
            w.visualOnly = visualOnly;
            w.lifeMs = lifeMs;
            out[i] = w;
            add(w);
        }
        return out;
    }

    /** v35 (I4): a destroyer-size hull leaves one burnt husk (the whole sprite), gone after 2 minutes; shooting it rolls wreck loot (owner). */
    static void husk(Element e, Drawable d) {
        Texture t = d.myTexture;
        if (t == null || t.name <= 0) return;
        float W, H;
        if (d instanceof ModFx.Sprite) { W = ((ModFx.Sprite) d).w; H = ((ModFx.Sprite) d).h; }
        else if (d.dimensions != null) { W = d.dimensions.x; H = d.dimensions.y; }
        else return;
        ModWreck w = new ModWreck();
        w.group = new boolean[] {false};
        w.husk = true;
        ModDev.ev("husk", "made from " + e.getClass().getSimpleName());
        w.srcClass = 1;
        w.srcElite = e instanceof Ennemis && ((Ennemis) e).elite;
        w.tex = t;
        w.u0 = 0; w.u1 = 1; w.v0 = 0; w.v1 = 1;
        w.w = W;
        w.h = H;
        w.tint = 0.4f;
        w.fadeMs = lifeMs(0);
        place(w, e, H, Math.max(W, H));
        w.maxLife = Math.max(100.0f, e.maxLife * 0.2f);
        w.life = w.maxLife;
        w.srcLevel = e.level;
        add(w);
    }

    static void add(ModWreck w) {
        w.lastVx = w.baseVx = w.speed.x;
        w.lastVy = w.baseVy = w.speed.y;
        if (w.visualOnly) {
            ObjectRegistry.INSTANCE.game.currentLevel.toAddDrawOnly.add(w);
            return;
        }
        live.add(w);
        for (int pass = 0; pass < 2 && live.size() > MAX; pass++) {
            // v35: husks go first, then the oldest wrecks; derelict sites, wreck fields and kept flagship wrecks stay
            for (int i = 0; i < live.size() && live.size() > MAX; i++) {
                ModWreck old = live.get(i);
                if (old.poi || old.playerOnly() || old == w || old.group != null && old.group == w.group || pass == 0 && !old.husk) continue;
                old.vanish();
                i--;
            }
        }
        ObjectRegistry.INSTANCE.game.currentLevel.toAdd.add(w);
    }

    /** Sector change (ModCaps.tick): the previous level's pieces are gone with it. */
    static void onLevel() {
        live.clear();
    }
}
